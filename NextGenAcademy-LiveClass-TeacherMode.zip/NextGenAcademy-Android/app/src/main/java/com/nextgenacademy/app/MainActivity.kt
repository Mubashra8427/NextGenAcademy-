package com.nextgenacademy.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private const val JITSI = "https://meet.jit.si/"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                NextGenApp { room ->
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(JITSI + room)))
                }
            }
        }
    }
}

@Composable
fun NextGenApp(openJitsi: (String) -> Unit) {
    var role by remember { mutableStateOf("Student") }
    var page by remember { mutableStateOf("Home") }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NextGen Academy") },
                actions = { TextButton(onClick = { role = if (role == "Student") "Teacher" else "Student" }) { Text(role) } }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Home","Live Class","Tests","Profile").forEach {
                    NavigationBarItem(selected = page == it, onClick = { page = it },
                        icon = { Text(it.first().toString()) }, label = { Text(it) })
                }
            }
        }
    ) { pad ->
        when(page) {
            "Live Class" -> LiveClass(role, openJitsi, Modifier.padding(pad))
            "Tests" -> Tests(Modifier.padding(pad))
            "Profile" -> Profile(role, Modifier.padding(pad))
            else -> Home(role, Modifier.padding(pad))
        }
    }
}

@Composable
fun Home(role: String, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Welcome to NextGen Academy", style = MaterialTheme.typography.headlineSmall) }
        item { Text("Online Tuition • Classes 6–10") }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("Subjects", style = MaterialTheme.typography.titleMedium)
            Text("Mathematics • Science • Social Science")
        }}}
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("Features", style = MaterialTheme.typography.titleMedium)
            Text("Live Classes • Recorded Lectures • Regular Tests • Assignments")
        }}}
        item { Text("Current mode: $role") }
    }
}

@Composable
fun LiveClass(role: String, openJitsi: (String) -> Unit, modifier: Modifier) {
    var room by remember { mutableStateOf("NextGenAcademyDemo") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Live Classes", style = MaterialTheme.typography.headlineSmall)
        Text(if(role == "Teacher") "Start a class on Jitsi Meet." else "Join your live class on Jitsi Meet.")
        OutlinedTextField(room, { room = it }, label = { Text("Class room name") }, singleLine = true,
            modifier = Modifier.fillMaxWidth())
        Button({ if(room.isNotBlank()) openJitsi(room.trim().replace(" ","-")) },
            Modifier.fillMaxWidth()) { Text(if(role == "Teacher") "Start Live Class" else "Join Live Class") }
        Text("Jitsi Meet will open for the live class.")
    }
}

@Composable
fun Tests(modifier: Modifier) {
    val tests = listOf("Mathematics – Class 10","Science – Class 9","Social Science – Class 8")
    LazyColumn(modifier.fillMaxSize().padding(20.dp)) {
        item { Text("Tests", style = MaterialTheme.typography.headlineSmall) }
        items(tests) { Text(it, modifier = Modifier.padding(vertical = 16.dp)) }
    }
}

@Composable
fun Profile(role: String, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineSmall)
        Text("Mode: $role")
        Text("Classes 6–10")
        Text("Mathematics • Science • Social Science")
    }
}
